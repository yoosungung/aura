'use strict';
const { handleResolve } = require('./bridge');

function parseBody(raw) {
  if (raw == null) return {};
  if (typeof raw === 'object' && !Buffer.isBuffer(raw)) return raw;
  let text = Buffer.isBuffer(raw) ? raw.toString('utf8') : String(raw);
  text = text.trim();
  if (!text) return {};
  return JSON.parse(text);
}

module.exports = async function (context) {
  let req;
  try {
    const raw =
      context && context.request && context.request.body != null
        ? context.request.body
        : '';
    req = parseBody(raw);
  } catch (err) {
    return {
      status: 400,
      body: JSON.stringify({
        type: 'control.resolve.error',
        ok: false,
        error: 'invalid_json',
        detail: String(err && err.message),
        subject: 'aura.rpc.control.resolve',
      }),
    };
  }
  const out = await handleResolve(req);
  const ok = out && out.ok === true;
  return {
    status: ok ? 200 : 400,
    body: JSON.stringify(out),
  };
};
