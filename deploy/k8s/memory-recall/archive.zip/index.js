'use strict';
module.exports = require('./recall/handler').handler;
